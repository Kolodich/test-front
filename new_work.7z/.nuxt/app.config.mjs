
import { defuFn } from 'D:/OpenServer/domains/new_work/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default /* #__PURE__ */ defuFn(inlineConfig)

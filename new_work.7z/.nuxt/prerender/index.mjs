globalThis._importMeta_={url:import.meta.url,env:process.env};import 'file://D:/OpenServer/domains/new_work/node_modules/node-fetch-native/dist/polyfill.mjs';
export { l as localFetch } from './chunks/nitro-prerenderer.mjs';
import 'file://D:/OpenServer/domains/new_work/node_modules/h3/dist/index.mjs';
import 'file://D:/OpenServer/domains/new_work/node_modules/ofetch/dist/node.mjs';
import 'file://D:/OpenServer/domains/new_work/node_modules/destr/dist/index.mjs';
import 'file://D:/OpenServer/domains/new_work/node_modules/unenv/runtime/fetch/index.mjs';
import 'file://D:/OpenServer/domains/new_work/node_modules/hookable/dist/index.mjs';
import 'file://D:/OpenServer/domains/new_work/node_modules/scule/dist/index.mjs';
import 'file://D:/OpenServer/domains/new_work/node_modules/defu/dist/defu.mjs';
import 'file://D:/OpenServer/domains/new_work/node_modules/ohash/dist/index.mjs';
import 'file://D:/OpenServer/domains/new_work/node_modules/ufo/dist/index.mjs';
import 'file://D:/OpenServer/domains/new_work/node_modules/unstorage/dist/index.mjs';
import 'file://D:/OpenServer/domains/new_work/node_modules/unstorage/drivers/fs.mjs';
import 'file://D:/OpenServer/domains/new_work/node_modules/radix3/dist/index.mjs';
//# sourceMappingURL=index.mjs.map

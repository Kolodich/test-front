const app_vue_vue_type_style_index_0_lang = "";

const appStyles_9e9a299a = [app_vue_vue_type_style_index_0_lang];

export { appStyles_9e9a299a as default };
//# sourceMappingURL=app-styles.9e9a299a.mjs.map

<template>
	<div class="_document">
		<div class="document__container">
			<div class="document__name">
				{{ name }}
			</div>

			<div class="document__statuses">

			</div>

			<div
				v-if="required"
				class="document__required"
			>
				Обязательный
			</div>

			<div
				v-if="desc"
				class="document__desc"
			>
				{{ desc }}
			</div>

			<div class="document__btn-list">
				<nuxt-icon
					class="document__btn"
					name="bookmark"
					filled
				/>
				<nuxt-icon
					class="document__btn"
					name="canBin"
					filled
				/>
				<nuxt-icon
					class="handle document__btn document__btn--drag"
					name="dragVertical"
					filled
				/>
			</div>
		</div>
	</div>
</template>

<script setup>

const props = defineProps({
	name: String,
	desc: String,
	statuses: Array,
	required: Boolean,
});

const { name, desc, statuses, required } = toRefs(props);

</script>

<style lang="scss" scoped>

.document {

	&__container {
		display: flex;
		gap: 15px;
		border: var(--border);
		padding: 13px 16px;
		color: var(--c-black);
		align-items: center;
	}

	&__name {
		font-size: 13px;
	}

	&__desc {
		color: var(--c-dark-gray);
		font-size: 11px;
	}

	&__required {
		font-size: 11px;
		color: var(--c-pink);
	}

	&__btn-list {
		display: flex;
		gap: 10px;
		margin-left: auto;
	}

	&__btn {
		cursor: pointer;

		&--drag {
			cursor: move;
			cursor: grab;
			cursor: -moz-grab;
			cursor: -webkit-grab;
		}
	}
}

</style>

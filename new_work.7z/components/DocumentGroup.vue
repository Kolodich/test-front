<template>
	<div class="document-group">
		<div class="document-group__container">
			<div
				class="document-group__name"
				@click="onToggle"
			>
				{{ name }}
			</div>

			<div v-if="statuses && statuses.length" class="document-group__statuses">

			</div>

			<div
				v-if="desc"
				class="document-group__desc"
			>
				{{ desc }}
			</div>

			<div class="document-group__btn-list">
				<nuxt-icon
					class="document-group__btn"
					name="bookmark"
					filled
				/>
				<nuxt-icon
					class="document-group__btn"
					name="canBin"
					filled
				/>
				<nuxt-icon
					class="handle document-group__btn document-group__btn--drag"
					name="dragVertical"
					filled
				/>
			</div>
		</div>

		<transition
			name="accordion"
			@enter="onExpanding"
			@after-enter="onCollapsing"
			@before-leave="onExpanding"
			@after-leave="onCollapsing"
		>
			<div
				v-show="expanded"
				class="document-group__documents"
			>
				<draggable
					:list="documents"
					item-key="id"
					tag="ul"
					v-bind="dragOptions"
					ghost-class="ghost"
					handle=".handle"
					group="documents"
					@start="onStartDragging"
					@end="onEndDragging"
				>
					<template #item="{ element }">
						<Document v-bind="element"/>
					</template>
				</draggable>

			</div>
		</transition>
	</div>
</template>

<script setup>

import draggable from 'vuedraggable'
import Document from './Document.vue';

const dragOptions = {
	animation: 250,
	group: "description",
	disabled: false,
	ghostClass: "ghost"
};

const props = defineProps({
	name: String,
	desc: String,
	statuses: Array,
	documents: Array,
	expanded: Boolean
});

const { name, desc, statuses } = toRefs(props);

const expanded = ref(false);

const emit = defineEmits(['update:documents', 'update:expanded']);

function updateDocuments(value) {
	emit('update:documents', value)
}

function updateExpanded(value) {
	emit('update:expanded', value)
}

function onStartDragging(event) {
	console.log('onStartDragging', event);
}

const onEndDragging = event => {
	console.log('onEndDragging', event);
}

function onToggle() {
	expanded.value = !expanded.value;
}

function onExpanding(el) {
	el.style.height = el.scrollHeight + "px";
};

function onCollapsing(el) {
	el.style.height = "";
}

</script>

<style lang="scss" scoped>

@import '../assets/css/mixins/index.scss';

.document-group {
	--border-width: 1px;

	&__container {
		display: flex;
		gap: 15px;
		border: var(--border);
		padding: 13px 16px;
		color: var(--c-black);
		align-items: center;
	}

	&__name,
	&__desc {
		position: relative;
		overflow: hidden;
		white-space: nowrap;
	}

	&__name {
		flex: none;
		font-size: 15px;
	}

	&__desc {
		flex: auto;
		color: var(--c-dark-gray);
		font-size: 11px;

		@include inner-shadow-right(14px);
	}

	&__required {
		font-size: 11px;
		color: var(--c-pink);
	}

	&__btn-list {
		margin-left: auto;
		display: flex;
		gap: 10px;
	}

	&__btn {
		cursor: pointer;

		&--drag {
			cursor: move;
			cursor: grab;
			cursor: -moz-grab;
			cursor: -webkit-grab;
		}
	}

	&__documents {
		padding-left: 16px;
		margin-top: calc(var(--border-width) * -1);

	}
}

.accordion-enter-active,
.accordion-leave-active {
  will-change: height, opacity;
  transition-property: height, opacity;
  transition-duration: 0.4s;
  transition-delay: 0.2s;
  overflow: hidden;
}

.accordion-enter-active {

}


.accordion-enter,
.accordion-leave-to {
  height: 0 !important;
  opacity: 0;
}

.ghost {
	transition: 0.2s opacity;
	opacity: 0.8;
}

</style>

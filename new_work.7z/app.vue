<template>
	<div class="container">
		<div class="documents">
			<draggable
				:list="data.documentGroups"
				item-key="id"
				tag="ul"
				v-bind="{ animation: 250, group: 'documentGroups', ghostClass: 'ghost' }"
				ghost-class="ghost"
				handle=".document-group__container .handle"
				class="documents__groups"
				@start="onStartDragging"
				@end="onEndDragging"
			>
				<template #item="{element}">
					<DocumentGroup v-bind="element"/>
				</template>
			</draggable>

			<draggable
				:list="data.documents"
				item-key="id"
				tag="ul"
				v-bind="{ animation: 250, group: 'documents', ghostClass: 'ghost' }"
				ghost-class="ghost"
				handle=".handle"
				class="documents__items"
				group="documents"
				@start="onStartDragging"
				@end="onEndDragging"
			>
				<template #item="{element}">
					<Document v-bind="element"/>
				</template>
			</draggable>
		</div>
	</div>
</template>

<script setup>

import data from '@/data/documents';

import draggable from 'vuedraggable'
import move from '@/utils/Array/move';

import Document from '@/components/Document.vue';
import DocumentGroup from '@/components/DocumentGroup.vue';

const dragOptions = {
	animation: 250,
	group: "description",
	disabled: false,
	ghostClass: "ghost"
};

let list = reactive(data.documentGroups);

function onStartDragging(event) {
	console.log(event);
}

const onEndDragging = event => {
	list
	move(list, event.oldIndex, event.newIndex);
}

function identifyComponent(value) {
	switch (value.type) {
		case 'documentGroup': return DocumentGroup
		default: return Document
	}
}

</script>

<style lang="scss" scoped>



.ghost {
	transition: 0.2s opacity;
	opacity: 0.8;
}

.flip-list-move {
  transition: transform 0.5s;
}
.no-move {
  transition: transform 0s;
}

.documents {
	padding: 40px;

	&__groups {
		margin-bottom: 14px;
	}

	&__items {

	}
}

</style>

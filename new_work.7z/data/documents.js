export const documents = [
	{
		id: 1,
		type: 'document',
		name: 'Паспорт',
		required: true,
		desc: 'Для всех'
	},
	{
		id: 2,
		type: 'document',
		name: 'ИНН',
		required: true,
		desc: 'Для всех'
	},
	{
		id: 3,
		type: 'document',
		name: 'Тестовое задание кандидата',
		desc: 'Россия, Белоруссия, Украина, администратор филиала, повар-сушист, повар-пиццмейкер, повар горячего цеха',
		required: false,
	},
	{
		id: 4,
		type: 'document',
		name: 'Трудовой договор',
		required: false,
	},
	{
		id: 5,
		type: 'document',
		name: 'Мед. книжка',
		required: false,
	},
]

export const documentGroups = [
	{
		id: 1,
		type: 'documentGroup',
		name: 'Обязательные для всех',
		desc: 'Документы, обязательные для всех сотрудников без исключения',
		documents: [ documents.shift(), documents.shift() ]
	},
	{
		id: 2,
		type: 'documentGroup',
		name: 'Обязательные для трудоустройства',
		desc: 'Документы, без которых невозможно трудоустройство человека на какую бы то ни было должность в компании вне зависимости от граж',
		documents: []
	},
	{
		id: 3,
		type: 'documentGroup',
		name: 'Специальные',
		documents: []
	},
];


export default {
	documents,
	documentGroups
}

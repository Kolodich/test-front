
export default () => {

	/**
	 * @typedef DocumentProps
	 * @property {string} name
	 * @property {string} desc
	 * @property {number[]} statuses
	 * @property {boolean} required
	 */

	/** @type {{ document: DocumentProps }} */
	const props = defineProps();

	return {
		props
	}
}
